import java.io.*;
import java.util.*;

public class Vasarlo {
	public final String nev;
	protected String igazolvanySzam;
	private int penz;
	
	public Vasarlo(String nev, String igazolvanySzam) {
		this.nev = nev;
		this.igazolvanySzam = igazolvanySzam;
		this.penz = 0;
	}
	
	public int getPenz() {
		return this.penz;
	}
	
	public void penztKolt(int mennyit) {
		if(getPenz() < mennyit) {
			throw new IllegalArgumentException("Nincs eleg penz!");
		}			
		this.penz -= mennyit;
	}
	
	public void penztKap(int mennyit) {
		this.penz += mennyit;
	}
	
	public void vagyontKiszamit(String fajlnev) {
		Scanner scn = new Scanner(fajlnev);
			while(scn.hasNextLine()) {
				String nextLN = scn.nextLine();
				String felbontott[] = nextLN.split(";");
				if(felbontott[1].equalsIgnoreCase("KIADAS")) {
					penztKap(Integer.parseInt(felbontott[2]));
				}else {
					
				}
		}
	}
}
