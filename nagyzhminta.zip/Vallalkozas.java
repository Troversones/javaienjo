
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Vallalkozas {
    private final Set<Integer> befektetesek = new HashSet<>();

    public int getPenz() {
        int osszeg = 0;

        for (int penz: befektetesek) {
            osszeg += penz;
        }

        return osszeg;
    }

    public void penztKolt(int mennyit) {
        if (getPenz() < mennyit) {
            throw new IllegalArgumentException("Nincs eleg penz!");
        }

        Iterator<Integer> iterator = befektetesek.iterator();
        while (iterator.hasNext() && mennyit > 0) {
            int elem = iterator.next();
            mennyit -= elem;
            iterator.remove();
        }

        befektetesek.add(-mennyit);
    }
}
