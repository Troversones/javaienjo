
public abstract class Kavefozo {
    private final int maxViz;
    private String kavefajta;
    private int vizMennyiseg=0;

    public Kavefozo(int maxViz) {
        this.maxViz = maxViz;
    }

    public boolean kavebabotBerak(String kavefajta) {
        if (this.kavefajta != null) {
            return false;
        }
        this.kavefajta = kavefajta;
        return true;
    }

    public void kavebabotKivesz() {
        this.kavefajta = null;
    }

    public void vizetTolt() {
        this.vizMennyiseg = this.maxViz;
    }

    public abstract boolean keszit(String mit, int mennyiVizzel);

    public int getVizMennyiseg() {
        return vizMennyiseg;
    }

    public String getKavefajta() {
        return kavefajta;
    }

}
